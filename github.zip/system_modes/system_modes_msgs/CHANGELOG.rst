^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package system_modes_examples
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.9.0 (2020-07-21)
------------------

* More flexibility in specifying the default mode, any mode can be now default mode
  https://github.com/micro-ROS/system_modes/issues/69

0.8.0 (2020-04-22)
------------------

* Launch integration, i.e. launch actions, events, and event handlers for system modes

0.7.1 (2020-04-22)
------------------

* Improved metadata for ROS 2 package releases

0.7.0 (2020-04-22)
------------------

* Launch tests now using launch_ros node action https://github.com/micro-ROS/system_modes/pull/72
* Introduced separate interface package, system_modes_msgs https://github.com/micro-ROS/system_modes/pull/74
